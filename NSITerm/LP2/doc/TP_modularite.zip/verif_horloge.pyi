"""
Module verif_horloge : vérificateurs pour le TP « Modularité ».

Chaque fonction verifier_xxx(f) teste la fonction f (écrite par l'élève) en la
comparant à une implémentation de référence que l'élève ne voit pas, puis
affiche un rapport. Elle ne renvoie rien.
"""
from typing import Callable

def verifier_difference_durees(
    f: Callable[[tuple[int, int, int], tuple[int, int, int]], int]
) -> None:
    """
    Vérifie une implémentation de difference_durees(t1, t2) -> int.

    f : la fonction à tester (celle de l'élève)
    affiche un rapport (résultats, puis préconditions)
    """
    ...

def verifier_additionner_durees(
    f: Callable[[int, int], tuple[int, int, int]]
) -> None:
    """
    Vérifie une implémentation de additionner_durees(duree1_sec, duree2_sec).

    f : la fonction à tester (celle de l'élève)
    affiche un rapport (résultats, puis préconditions)
    """
    ...
