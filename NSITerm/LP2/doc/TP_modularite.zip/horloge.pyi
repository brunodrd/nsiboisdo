"""
Module horloge : Outils de conversion et manipulation de durées.
"""

def en_secondes(h: int, m: int, s: int) -> int:
    """
    Convertit une durée exprimée en heures, minutes et secondes en un
    nombre total de secondes.

    h : nombre d'heures (entier positif ou nul)
    m : nombre de minutes (entier, 0 <= m < 60)
    s : nombre de secondes (entier, 0 <= s < 60)
    renvoie le nombre total de secondes correspondant
    """
    ...

def en_hms(secondes: int) -> tuple[int, int, int]:
    """
    Convertit un nombre total de secondes en un triplet (heures, minutes, secondes).

    secondes : nombre total de secondes (entier positif ou nul)
    renvoie un tuple (h, m, s) représentant la même durée
    """
    ...

def formater_duree(secondes: int) -> str:
    """
    Renvoie une durée sous la forme d'une chaîne lisible "HH:MM:SS".

    secondes : nombre total de secondes (entier positif ou nul)
    renvoie une chaîne de caractères au format "HH:MM:SS"
    """
    ...
