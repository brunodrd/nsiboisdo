# Hello world pour le Plug'Py
# Fait clignoter une led connectée à la broche D2

from ppy import delay, Pin


__author__ = "Bruno DARID"
__license__ = "CC-BY-NC-SA 4.0"
__email__ = "bruno.darid@ac-reunion.fr"

def blink(alpha=0.5):
    """
    Fait clignoter une led branchée sur D2 avec un rapport
    cyclique de 'alpha';
    alpha: float, vaut 0.5 par défaut
    0 <= alpha <= 1
    """
    assert 0 <= alpha <= 1, "Erreur rapport cyclique"
    led = Pin('D2', Pin.OUT) # crée un objet de la classe Pin associé à la broche D2
    while True: # boucle infinie
        led.on()
        delay(int(alpha * 1000)) # durée etat haut
        led.off()
        delay(int((1 - alpha) * 1000)) # durée état bas

if __name__ == "__main__":
    blink(0.7)