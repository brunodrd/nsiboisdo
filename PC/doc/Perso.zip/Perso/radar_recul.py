# Principe du radar de recul
# Utilisation du module 'Télémètre' réf. Sciencethic 651 049
# on simule l'alarme en envoyant un son sur la sortie A0, par
# l'intermédiaire d'un convertisseur numérique/analogique (DAC)

from lib.USRanger import USRanger
from ppy import Pin, delay, DAC
from math import sin, pi


__author__ = 'Bruno DARID'
__license__ = 'CC-BY-NC-SA 4.0'
__email__ = 'bruno.darid@ac-reunion.fr'


def alarme(sortie, off=False):
    """ Produit d'un son sinusoidal de freq = 600 Hz;
    sortie: instance de DAC
    off: booleen, si off=True, alors on coupe le son.
    """
    
    if off:
        sortie.write(0)
    else:
        buf = bytearray(100) # tableau d'octets pour un buffer
        for i in range(100):
            # Remplissage du buffer contenant la fonction sinus
            buf[i] = 128 + int(127 * sin(2 * pi * i / 100))
        # voir documentation pour la syntaxe de write_timed
        sortie.write_timed(buf, 600 * len(buf), mode=DAC.CIRCULAR)

def main():
    # Affectation des broches: télémètre sur D2 et son sur A0
    module = USRanger(Pin('D2', Pin.OUT))
    sortie_son = DAC(Pin('A0', Pin.OUT))
    
    while True:
        # Il vaudrait mieux effectuer une moyenne sur quelques mesures
        # plutot qu'une seule !
        mesures = []
        for i in range(20):
            # Utilisation de la librairie pour la mesure de d
            mesures.append(module.mesureCentimeters())
            delay(10)
        dist = sum(mesures) / len(mesures)
        # Prise de décision suivant la valeur de la distance
        #print(dist)
        if dist < 30:
            print(dist)
            alarme(sortie_son)
        else:
            alarme(sortie_son, off=True)


if __name__ == "__main__":
    main()