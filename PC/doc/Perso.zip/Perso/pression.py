# Relevé de la pression en fonction du volume d'air emprisonné dans une seringue.
# La sauvegarde se fait dans un fichier csv

import os
from ppy import ADC, Pin

__author__ = 'Bruno DARID'
__license__ = 'CC-BY-NC-SA 4.0'
__email__ = 'bruno.darid@ac-reunion.fr'

# Quelques 'constantes'
MSG = """==== Relevé de la pression en fonction du volume ====
1) A l'invite, entrer le volume d'air présent dans la seringue
2) Pour quitter --> ctrl + C
"""

def lecture(entree):
    """ Réalise une conversion A/N sur 'entree' et renvoie sa valeur """

    return entree.read()

def acquisition(nom_fichier, entree):
    """ Demande une valeur de volume et mesure la pression correspondante. Les résultats sont
    écrits dans 'nom_fichier'.csv
    nom_fichier: chaine correspondant au nom du fichier SANS EXTENSION.
    entree: instance de classe ADC, désigne la broche sur laquelle est branchée le module
    """

    with open(nom_fichier + '.csv', 'w') as f:
        while True:
            v = input('Nouvelle valeur de volume (mL): ')
            volume = float(v)
            n = lecture(entree) # demande une conversion
            f.write(str(n * 3010 / 4095) + ';' + str(volume + 3.1) + '\n') # Sauvegarde 'Pression ; Volume' dans le fichier csv
            # On a tenu compte du volume de 3.1 mL (tuyau avant capteur)
            # 3010 est le facteur de proportionnalité entre P et la tension d'entrée

def main():
    print(MSG)
    os.chdir('/flash/Samples/Perso') # Se déplacer dans le rép. de travail perso
    entree_A3 = ADC(Pin('A3', Pin.IN)) # On suppose que le capteur est branché sur A3
    acquisition('PV', entree_A3)
    

if __name__ == "__main__":
    main()